//nama : Pavita Andrea
//NIM : 18220014
//Tanggal : 16 September 2021


#include "boolean.h"
#include "array.h"
#include <stdio.h>

int main (){
	int n;
	scanf("%d\n",&a);
	

}
