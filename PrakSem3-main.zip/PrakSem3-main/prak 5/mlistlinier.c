/*
NIM: 18220014
Nama : Pavita Andrea
Tanggal : 28 Oktober 2021
Topik praktikum : list linear
Deskripsi : no 1
*/
#include "listlinier.h"
#include "boolean.h"
#include <stdio.h>

int main()
{
	int n,i,j,k;
	scanf("%d", &n);
	List L;
	CreateEmpty (&L);
	for (i = 0; i < n; ++i){
		int a,b,c;
		scanf("%d", &a);
        if(a == 3) 
		{
			scanf("%d", &b) ;
            if (NbElmt(L) < (b * 2)) {
                printf("-1 -1\n") ;
            }
            else {
                infotype temp1, temp2, min, max ;
                DelVFirst(&L, &temp1) ;
                DelVLast(&L, &temp2) ;
                if (temp1 <= temp2) {
                    min = temp1 ;
                    max = temp2 ;
                }
                else {
                    min = temp2 ;
                    max = temp1 ;
                }
                for (k = 1; k < b; k++) {
                    DelVFirst(&L, &temp1) ;
                    DelVLast(&L, &temp2) ;
                    if (temp1 <= min) {
                        min = temp1;
                    }
                    if (temp2 <= min) {
                        min = temp2;
                    }
                    if (temp1 >= max) {
                        max = temp1;
                    }
                    if (temp2 >= max) {
                        max = temp2;
                    }
                }
                printf("%d %d\n", min, max);
            }
    	} 
		else if (a == 1) 
		{
			scanf("%d %d", &b, &c);
			for(j = 0; j<c ; j++){
				InsVFirst(&L, b);
			}

        }
		else
		{
			scanf("%d %d", &b, &c);
			for(j = 0; j<c ; j++){
				InsVLast(&L, b);
			}			
		} 
	}
}
