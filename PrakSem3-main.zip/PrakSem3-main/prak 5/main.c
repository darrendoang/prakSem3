#include "listlinier.h"
#include <stdio.h>

int main()
{
	int n,i,j,k;
	scanf("%d", &n);
	List L;
	CreateEmpty (&L);
	for (i = 0; i < n; ++i){
		int a,b,c;
		scanf("%d", &a);
        if(a == 3) 
		{
            scanf("%d",&b);
            for(k=0 ; k<b; k++){
            	if (NbElmt(L) <= 1) 
				{
                	printf("-1 -1") ;
        		}
        		else
        		{
        			infotype temp1, temp2 ;
                	DelVFirst(&L, &temp1) ;
                	DelVLast(&L, &temp2) ;
                	if (temp1 <= temp2) {
                    	printf("%d %d", temp1, temp2) ;
                	}
                	else {
                    	printf("%d %d", temp2, temp1) ;
                	}
				}
			}
    	} 
		else if (a == 1) 
		{
			scanf("%d %d", &b, &c);
			for(j = 0; j<c ; j++){
				InsVFirst(&L, b);
			}
        }
		else
		{
			scanf("%d %d", &b, &c);
			for(j = 0; j<c ; j++){
				InsVLast(&L, b);
			}			
		} 
	}
}
