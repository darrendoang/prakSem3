/*
NIM: 18220014
Nama : Pavita Andrea
Tanggal : 4 November 2021
Topik praktikum : variasi list linear
Deskripsi : no 2
*/

#include "listdp.h"
#include <stdio.h>

int main () {
    List L ;
    CreateEmpty(&L) ;
    address P ;
    int n, i, X, total, jumlah ;
    scanf("%d", &n) ;
    total = 0 ;
    jumlah = 0 ;
    for (i = 0; i < n; i++) {
        scanf("%d", &X) ;
        if (X > 0) {
            if (jumlah < 10) {
                InsVLast(&L, X) ;
                jumlah++ ;
                total = total + X ;
                printf("%d %d\n", jumlah, total) ;
            }
            else {
                printf("Skill penuh\n") ;
            }
        }
        else {
            P = Search(L, X*-1) ;
            if (P == Nil) {
                printf("Tidak ada skill\n") ;
            }
            else {
                DelP(&L, X*-1) ;
                jumlah-- ;
                total = total + X ;
                printf("%d %d\n", jumlah, total) ;
            }
        }
    }
    return 0 ;
}
