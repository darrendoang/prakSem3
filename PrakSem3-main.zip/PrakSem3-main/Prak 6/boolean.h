#ifndef BOOLEAN_H
#define BOOLEAN_H

#define boolean unsigned char
#define true 1
#define false 0

#endif
