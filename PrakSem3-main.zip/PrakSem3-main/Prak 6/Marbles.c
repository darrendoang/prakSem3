/* 
Nama : Pavita Anrea
NIM : 18220014
Soal : Marbles
*/

#include <stdio.h>

void Marbles(char *input){
    int a, b, acc;
    scanf("%d %d", &a, &b);
    if (a != 2 || b != 2 || a > 15){
        illegal_move();
    }
    acc = func4(a, 0, 14);
    if (acc != 11 || b != 11){
        illegal_move();
    }
}

int func4(int a, int b, int c)
{
    int result;
    result = b + (c - a) / 2;
    if (result > a)
    {
        result += func4(a, b, c - 1);
    }
    else if (result < a)
    {
        result += func4(a, b + 1, c);
    }
    return result;
}
