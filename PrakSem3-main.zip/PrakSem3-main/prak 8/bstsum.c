/*
NIM: 18220014
Nama : Pavita Andrea
Tanggal : 18 November 2021
Topik praktikum : binary tree
Deskripsi : no 2
*/

#include "boolean.h"
#include "bintree.h"
#include <stdio.h>
#include <stdlib.h>

void insertTree(infotype X, BinTree *P);
void insertTree(infotype X, BinTree *P) {
    if (IsTreeEmpty(*P)) 
    {
        (*P) = AlokNode(X);
    }
    else
    {
        if (X <= Akar(*P))
        {
            insertTree(X, &Left(*P));
        }
        else
        {
            insertTree(X, &Right(*P));
        }
    }
}
int getSum(BinTree T);
int getSum(BinTree T){
	int sum;
	sum = 0;
	if (IsTreeEmpty(T)) 
    {
        return 0;
    }
    else
    {
    	sum = Akar(T)+getSum(Left(T))+getSum(Right(T));
    	return sum;
	}
	
}
addrNode SearchAddress (BinTree T, infotype X);
addrNode SearchAddress (BinTree T, infotype X) {
    if (Akar(T) == X) {
        return T ;
    }
    else {
        if (SearchTree(Left(T), X)) {
            SearchAddress(Left(T), X) ;
        }
        else {
            SearchAddress(Right(T), X) ;
        }
    }
}

int main () {
    BinTree P,temp;
    int n, i, cinfo,a;
    scanf("%d", &n);
    i = 0;
    P = Nil;
    temp = Nil;
    while (i < n)
    {
        scanf("%d", &cinfo);
        insertTree(cinfo, &P);
        i++;
    }
    scanf("%d", &a);
    printf("%d\n", getSum(SearchAddress(P, a))) ;
}
